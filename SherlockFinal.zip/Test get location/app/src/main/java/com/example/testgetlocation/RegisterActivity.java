package com.example.testgetlocation;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {

    private EditText pinEditText;
    private Button registerButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_screen);

        // Initialize EditText and Button views
        pinEditText = findViewById(R.id.pinEditText);
        registerButton = findViewById(R.id.registerButton);

        // Set an OnClickListener for the registerButton
        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Get the PIN entered by the user
                String pin = pinEditText.getText().toString();
                // Check if the PIN has 4 digits
                if (pin.length() == 4) {
                    // Save the PIN to SharedPreferences
                    savePinToPreferences(pin);
                    // Display a success message
                    Toast.makeText(RegisterActivity.this, "PIN registered successfully", Toast.LENGTH_SHORT).show();
                    // Finish the RegisterActivity
                    finish();
                } else {
                    // Display an error message if the PIN is not 4 digits
                    Toast.makeText(RegisterActivity.this, "PIN should be 4 digits", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    // Save the PIN to SharedPreferences
    private void savePinToPreferences(String pin) {
        // Get a reference to SharedPreferences
        SharedPreferences preferences = getSharedPreferences("MyPrefs", MODE_PRIVATE);
        // Create an editor to modify SharedPreferences
        SharedPreferences.Editor editor = preferences.edit();
        // Store the PIN in SharedPreferences
        editor.putString("pin", pin);
        // Apply the changes to SharedPreferences
        editor.apply();
    }
}

package com.example.testgetlocation;
public class Contact {
    private String phoneNumber;
    private String contactName;

    public Contact(String phoneNumber, String contactName) {
        this.phoneNumber = phoneNumber;
        this.contactName = contactName;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getContactName() {
        return contactName;
    }
}

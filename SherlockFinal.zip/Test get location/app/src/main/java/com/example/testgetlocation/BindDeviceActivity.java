package com.example.testgetlocation;




import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.telephony.SmsManager;

public class BindDeviceActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 101;
    private EditText phoneNumberEditText;
    private Button bindDeviceButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_binddevice);

        phoneNumberEditText = findViewById(R.id.phoneNumberEditText);
        bindDeviceButton = findViewById(R.id.bindDeviceButton);

        bindDeviceButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String phoneNumber = phoneNumberEditText.getText().toString();
                if (!phoneNumber.isEmpty()) {
                    // Check for SMS permission
                    if (checkSmsPermission()) {
                        sendSms(phoneNumber);
                        Toast.makeText(BindDeviceActivity.this, "Bind request send successfully, Please check your phone SMS.", Toast.LENGTH_SHORT).show();
                    } else {
                        requestSmsPermission();
                    }
                } else {
                    Toast.makeText(BindDeviceActivity.this, "Please enter a valid phone number", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private boolean checkSmsPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestSmsPermission() {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                String phoneNumber = phoneNumberEditText.getText().toString();
                if (!phoneNumber.isEmpty()) {
                    sendSms(phoneNumber);
                }
            } else {
                Toast.makeText(this, "SMS permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void sendSms(String phoneNumber) {
        String message = "Device Bound Successfully!, Now add this device trough add device option in Sherlock app. Thank you!";

        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "SMS sent successfully to " + phoneNumber, Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Failed to send SMS", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
}
}
}
package com.example.testgetlocation;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.telephony.SmsManager;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class ShowLocationActivity extends AppCompatActivity {

    // Request codes for permissions and activities
    private static final int SMS_PERMISSION_REQUEST_CODE = 1;
    private static final int CALL_PERMISSION_REQUEST_CODE = 2;
    private static final int ADD_PHONE_NUMBER_REQUEST_CODE = 3;

    // UI elements
    private EditText phoneNumberEditText;
    private Spinner phoneNumberSpinner;
    private TextView smsTextView;
    private Button requestLocationButton;

    private static final int SMS_PERMISSION_CODE = 101;

    // Data structures for managing phone numbers
    private List<String> phoneNumbersList;
    private ArrayAdapter<String> phoneNumberAdapter;
    private Map<String, String> contactMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_location);

        // Initialize UI elements
        phoneNumberEditText = findViewById(R.id.phoneNumberEditText);
        phoneNumberSpinner = findViewById(R.id.phoneNumberSpinner);
        smsTextView = findViewById(R.id.smsTextView);
        requestLocationButton = findViewById(R.id.requestLocationButton);

        // Initialize data structures for managing phone numbers
        phoneNumbersList = new ArrayList<>();
        phoneNumberAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, phoneNumbersList);
        phoneNumberAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        phoneNumberSpinner.setAdapter(phoneNumberAdapter);

        // Set a listener for the spinner to populate the phone number EditText
        phoneNumberSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedContact = phoneNumbersList.get(position);
                String phoneNumber = contactMap.get(selectedContact);
                phoneNumberEditText.setText(phoneNumber);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Do nothing
            }
        });

        // Load registered phone numbers when the activity is created
        loadRegisteredPhoneNumbers();

        // Set the click listener for the requestLocationButton
        requestLocationButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String phoneNumber = phoneNumberEditText.getText().toString();
                if (!phoneNumber.isEmpty()) {
                    // Check for SMS permission
                    if (checkSmsPermission()) {
                        sendSms(phoneNumber);
                        Toast.makeText(ShowLocationActivity.this, "Location request sent. Please wait for the location SMS.", Toast.LENGTH_SHORT).show();
                    } else {
                        requestSmsPermission();
                    }
                } else {
                    Toast.makeText(ShowLocationActivity.this, "Please enter a valid phone number", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    // Load registered phone numbers from SharedPreferences
    private void loadRegisteredPhoneNumbers() {
        SharedPreferences sharedPreferences = getSharedPreferences("phone_numbers", MODE_PRIVATE);
        Set<String> phoneNumberSet = sharedPreferences.getStringSet("phone_numbers_set", new HashSet<>());

        phoneNumbersList.clear();
        contactMap = new HashMap<>();

        for (String storedValue : phoneNumberSet) {
            String[] parts = storedValue.split(":");
            if (parts.length >= 2) {
                String phoneNumber = parts[0];
                String contactName = parts[1];
                phoneNumbersList.add(contactName);
                contactMap.put(contactName, phoneNumber);
            }
        }

        phoneNumberAdapter.notifyDataSetChanged();
    }
///////////////////////////////////////////////////////////////////////

   //requestLocationButton.setOnClickListener(new View.OnClickListener()




    // Handle the "Show Location" button click
    public void onShowLocationClick(View view) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_SMS}, SMS_PERMISSION_REQUEST_CODE);
        } else {
            readLastSMSAndOpenURL();
        }
    }

    // Handle permission requests
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                readLastSMSAndOpenURL();
            } else {
                Toast.makeText(this, "SMS permission denied.", Toast.LENGTH_SHORT).show();
            }
        } else if (requestCode == CALL_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, make the call
                onCallButtonClick(null); // Call the button click method again
            } else {
                Toast.makeText(this, "Call permission denied.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // Read the last SMS and open the associated URL
    private void readLastSMSAndOpenURL() {
        String enteredPhoneNumber = phoneNumberEditText.getText().toString();

        if (enteredPhoneNumber.isEmpty()) {
            Toast.makeText(this, "Please enter a phone number.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Perform phone number formatting
        if (enteredPhoneNumber.startsWith("0")) {
            enteredPhoneNumber = enteredPhoneNumber.substring(1);
        }

        if (!enteredPhoneNumber.startsWith("+94")) {
            enteredPhoneNumber = "+94" + enteredPhoneNumber;
        }

        // Query SMS messages to find the last message from the specified phone number
        Uri uri = Uri.parse("content://sms/inbox");
        ContentResolver contentResolver = getContentResolver();
        String[] projection = new String[]{"_id", "address", "body"};
        String selection = "address = ?";
        String[] selectionArgs = new String[]{enteredPhoneNumber};
        String sortOrder = "date DESC";
        Cursor cursor = null;

        try {
            cursor = contentResolver.query(uri, projection, selection, selectionArgs, sortOrder);

            if (cursor != null && cursor.moveToFirst()) {
                @SuppressLint("Range") String body = cursor.getString(cursor.getColumnIndex("body"));
                smsTextView.setText(body);
                cursor.close();

                // Extract URL from the SMS message
                String extractedUrl = extractUrlFromMessage(body);
                if (!extractedUrl.isEmpty()) {
                    openURL(extractedUrl);
                } else {
                    Toast.makeText(this, "No location URL found in the SMS.", Toast.LENGTH_SHORT).show();
                }
            } else {
                smsTextView.setText("No SMS found from the specified phone number.");
            }
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Error reading SMS.", Toast.LENGTH_SHORT).show();
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
        }
    }

    // Extract URL from the SMS message
    private String extractUrlFromMessage(String message) {
        int startIndex = message.indexOf("http://");
        if (startIndex == -1) {
            startIndex = message.indexOf("https://");
        }

        if (startIndex != -1) {
            int endIndex = message.indexOf(" ", startIndex);
            if (endIndex == -1) {
                endIndex = message.length();
            }

            return message.substring(startIndex, endIndex);
        } else {
            return "";
        }
    }

    // Open the URL in a web browser
    private void openURL(String url) {
        if (!url.isEmpty()) {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            try {
                startActivity(intent);
            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(this, "Error opening URL: " + url, Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "No valid URL to open.", Toast.LENGTH_SHORT).show();
        }
    }

    // Handle the "Call" button click
    public void onCallButtonClick(View view) {
        String phoneNumber = phoneNumberEditText.getText().toString().trim();

        if (!phoneNumber.isEmpty()) {
            Intent callIntent = new Intent(Intent.ACTION_CALL);
            callIntent.setData(Uri.parse("tel:" + phoneNumber));

            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) {
                startActivity(callIntent);
            } else {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CALL_PHONE}, CALL_PERMISSION_REQUEST_CODE);
            }
        } else {
            Toast.makeText(this, "Please enter a phone number.", Toast.LENGTH_SHORT).show();
        }
    }



    // Handle the result of adding a new phone number
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == ADD_PHONE_NUMBER_REQUEST_CODE && resultCode == RESULT_OK) {
            boolean newPhoneNumberAdded = data.getBooleanExtra("newPhoneNumberAdded", false);
            if (newPhoneNumberAdded) {
                loadRegisteredPhoneNumbers();
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Load registered phone numbers every time the activity is resumed
        loadRegisteredPhoneNumbers();
    }

    private boolean checkSmsPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestSmsPermission() {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
    }

    private void sendSms(String phoneNumber) {
        String message = "GPS";

        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "SMS sent successfully to " + phoneNumber, Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Failed to send SMS", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }
}

package com.example.testgetlocation;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import java.util.HashSet;
import java.util.Set;

public class AddPhoneNumberActivity extends AppCompatActivity {

    private EditText newPhoneNumberEditText;
    private EditText newContactNameEditText;
    private Button addPhoneNumberButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_phone_number);

        newPhoneNumberEditText = findViewById(R.id.newPhoneNumberEditText);
        newContactNameEditText = findViewById(R.id.newContactNameEditText);
        addPhoneNumberButton = findViewById(R.id.addPhoneNumberButton);

        addPhoneNumberButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String phoneNumber = newPhoneNumberEditText.getText().toString();
                String contactName = newContactNameEditText.getText().toString();

                if (!phoneNumber.isEmpty() && !contactName.isEmpty()) {
                    // Save the new contact to SharedPreferences
                    saveContactToSharedPreferences(contactName, phoneNumber);

                    // Clear the input fields
                    newPhoneNumberEditText.setText("");
                    newContactNameEditText.setText("");
                    Toast.makeText(AddPhoneNumberActivity.this, "Device added to list successfully", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void saveContactToSharedPreferences(String contactName, String phoneNumber) {
        SharedPreferences sharedPreferences = getSharedPreferences("phone_numbers", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        Set<String> phoneNumberSet = new HashSet<>(sharedPreferences.getStringSet("phone_numbers_set", new HashSet<>()));

        // Format the contact data as a string and add it to the set
        String contactData = phoneNumber + ":" + contactName;
        phoneNumberSet.add(contactData);

        // Save the updated set back to SharedPreferences
        editor.putStringSet("phone_numbers_set", phoneNumberSet);
        editor.apply();
    }
}

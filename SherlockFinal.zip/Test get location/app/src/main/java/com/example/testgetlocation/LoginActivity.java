package com.example.testgetlocation;


// Importing required libraries
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private EditText pinEditText;
    private Button loginButton;
    private TextView registerLink;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_screen);

        // Initialize SharedPreferences for storing user data
        sharedPreferences = getSharedPreferences("MyPrefs", MODE_PRIVATE);

        if (!isPinRegistered()) {
            // If the PIN is not registered, show the registration screen
            setContentView(R.layout.activity_register_screen);
            // Initialize views and set up registration logic
            setupRegistration();
        } else {
            // If the PIN is registered, show the login screen
            setContentView(R.layout.activity_login_screen);
            // Initialize views and set up login logic
            setupLogin();
        }
    }

    // Check if the PIN is registered
    private boolean isPinRegistered() {
        return sharedPreferences.getBoolean("isPinRegistered", false);
    }

    private void setupRegistration() {
        // Initialize views for registration
        pinEditText = findViewById(R.id.pinEditText);
        Button registerButton = findViewById(R.id.registerButton);

        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String pin = pinEditText.getText().toString();
                if (pin.length() == 4) {
                    // Save the PIN to SharedPreferences
                    savePinToPreferences(pin);
                    Toast.makeText(LoginActivity.this, "PIN registered successfully", Toast.LENGTH_SHORT).show();
                    // Navigate to the login screen
                    Intent loginIntent = new Intent(LoginActivity.this, LoginActivity.class);
                    startActivity(loginIntent);
                    finish();
                } else {
                    Toast.makeText(LoginActivity.this, "PIN should be 4 digits", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    // Save the PIN to SharedPreferences
    private void savePinToPreferences(String pin) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean("isPinRegistered", true);
        editor.putString("pin", pin);
        editor.apply();
    }

    private void setupLogin() {
        // Initialize views for login
        pinEditText = findViewById(R.id.pinEditText);
        loginButton = findViewById(R.id.loginButton);
        registerLink = findViewById(R.id.registerLink);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String enteredPin = pinEditText.getText().toString();
                String savedPin = sharedPreferences.getString("pin", "");

                if (enteredPin.equals(savedPin)) {
                    Toast.makeText(LoginActivity.this, "Login successful", Toast.LENGTH_SHORT).show();
                    navigateToMainActivity();
                } else {
                    Toast.makeText(LoginActivity.this, "Invalid PIN", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Hide the "Don't have an account?" link after PIN registration
        if (isPinRegistered()) {
            registerLink.setVisibility(View.GONE);
        } else {
            registerLink.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    // Navigate to a different activity (DashboardActivity) for new users
                    startActivity(new Intent(LoginActivity.this, DashboardActivity.class));
                }
            });
        }
    }

    // Navigate to the main activity (DashboardActivity)
    private void navigateToMainActivity() {
        Intent intent = new Intent(LoginActivity.this, DashboardActivity.class);
        startActivity(intent);
        finish();
    }
}

package com.example.testgetlocation;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class DashboardActivity extends AppCompatActivity {

    // Declare CardViews for different actions
    CardView bindDevice;   // CardView for binding a device
    CardView addDevice;    // CardView for adding a device
    CardView showLocation; // CardView for showing the location

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        // Initialize CardViews by finding their respective views in the layout
        bindDevice = findViewById(R.id.bindDevice);
        addDevice = findViewById(R.id.addDevice);
        showLocation = findViewById(R.id.showLocation);

        // Set click listeners for the CardViews to navigate to different activities

        // Call to Bind Device Activity
        bindDevice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Create an intent to start the BindDeviceActivity
                Intent intent = new Intent(DashboardActivity.this, BindDeviceActivity.class);
                startActivity(intent);
            }
        });

        // Call to Add Device Activity
        addDevice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Create an intent to start the AddPhoneNumberActivity
                Intent intent = new Intent(DashboardActivity.this, AddPhoneNumberActivity.class);
                startActivity(intent);
            }
        });

        // Call to Show Location Activity
        showLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Create an intent to start the ShowLocationActivity
                Intent intent = new Intent(DashboardActivity.this, ShowLocationActivity.class);
                startActivity(intent);
            }
        });
    }
}
